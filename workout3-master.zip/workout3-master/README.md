# Stat133, Fall 2018, Workout 03

Private Repository for HW assignments of Stat133 fall 2018

-Name: MK Larson


-Github username: mklarsonn


-Email: mlarson@skycatch.com


-Lab Section: 109


-GSI: Zhiang Zhou


## OVERVIEW

This Workout involves creating our own R-package. With the package, I will be creating and implementing functions to simulate the events of rolling an object. 

This assignment will also demonstrate my understanding of github and the correct file structure for a package. 


## REASON

The reason for this code is for an assignment in my Stats133 class.
